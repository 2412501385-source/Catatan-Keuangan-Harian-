package com.budiluhur.catatankeuangan.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.budiluhur.catatankeuangan.R;
import com.budiluhur.catatankeuangan.model.Transaksi;

import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

/**
 * Adapter untuk menampilkan daftar Transaksi pada RecyclerView di MainActivity.
 * Mendukung klik item (untuk edit) dan klik tombol hapus (untuk delete via REST API).
 */
public class TransaksiAdapter extends RecyclerView.Adapter<TransaksiAdapter.ViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(Transaksi transaksi);
    }

    public interface OnDeleteClickListener {
        void onDeleteClick(Transaksi transaksi);
    }

    private List<Transaksi> daftarTransaksi;
    private final OnItemClickListener itemClickListener;
    private final OnDeleteClickListener deleteClickListener;

    public TransaksiAdapter(List<Transaksi> daftarTransaksi,
                             OnItemClickListener itemClickListener,
                             OnDeleteClickListener deleteClickListener) {
        this.daftarTransaksi = daftarTransaksi;
        this.itemClickListener = itemClickListener;
        this.deleteClickListener = deleteClickListener;
    }

    public void setData(List<Transaksi> data) {
        this.daftarTransaksi = data;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_transaksi, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Transaksi item = daftarTransaksi.get(position);

        holder.tvJudul.setText(item.getJudul());
        holder.tvKategoriTanggal.setText(item.getKategori() + " • " + item.getTanggal());

        NumberFormat formatRupiah = NumberFormat.getNumberInstance(new Locale("in", "ID"));
        String prefix = "Pemasukan".equalsIgnoreCase(item.getTipe()) ? "+Rp " : "-Rp ";
        holder.tvJumlah.setText(prefix + formatRupiah.format(item.getJumlah()));
        holder.tvJumlah.setTextColor(holder.itemView.getResources().getColor(
                "Pemasukan".equalsIgnoreCase(item.getTipe())
                        ? com.budiluhur.catatankeuangan.R.color.green_income
                        : com.budiluhur.catatankeuangan.R.color.red_expense
        ));

        holder.itemView.setOnClickListener(v -> itemClickListener.onItemClick(item));
        holder.btnDelete.setOnClickListener(v -> deleteClickListener.onDeleteClick(item));
    }

    @Override
    public int getItemCount() {
        return daftarTransaksi == null ? 0 : daftarTransaksi.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvJudul, tvKategoriTanggal, tvJumlah;
        android.widget.ImageButton btnDelete;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvJudul = itemView.findViewById(R.id.tvJudul);
            tvKategoriTanggal = itemView.findViewById(R.id.tvKategoriTanggal);
            tvJumlah = itemView.findViewById(R.id.tvJumlah);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
