package com.budiluhur.catatankeuangan.model;

import com.google.gson.annotations.SerializedName;

/**
 * Wrapper response standar untuk operasi Create, Update, Delete pada REST API.
 * Backend PHP selalu mengembalikan JSON: {"status": "success/error", "message": "..."}
 */
public class ApiResponse {

    @SerializedName("status")
    private String status;

    @SerializedName("message")
    private String message;

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public boolean isSuccess() {
        return "success".equalsIgnoreCase(status);
    }
}
