package com.budiluhur.catatankeuangan;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.budiluhur.catatankeuangan.adapter.TransaksiAdapter;
import com.budiluhur.catatankeuangan.api.ApiClient;
import com.budiluhur.catatankeuangan.model.ApiResponse;
import com.budiluhur.catatankeuangan.model.Transaksi;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Activity 2 dari 3: Halaman utama (daftar transaksi).
 * Menampilkan seluruh data transaksi dari server (REST API -> MySQL) menggunakan RecyclerView,
 * mendukung pull-to-refresh, hapus data, dan navigasi (Intent) ke AddEditActivity
 * untuk menambah/mengubah data.
 */
public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_MODE = "extra_mode";
    public static final String EXTRA_ID = "extra_id";
    public static final String EXTRA_JUDUL = "extra_judul";
    public static final String EXTRA_KATEGORI = "extra_kategori";
    public static final String EXTRA_TIPE = "extra_tipe";
    public static final String EXTRA_JUMLAH = "extra_jumlah";
    public static final String EXTRA_TANGGAL = "extra_tanggal";
    public static final String EXTRA_DESKRIPSI = "extra_deskripsi";
    public static final String MODE_EDIT = "edit";
    public static final String MODE_ADD = "add";

    private RecyclerView rvTransaksi;
    private SwipeRefreshLayout swipeRefresh;
    private TextView tvEmpty, tvSaldo;
    private View progressBar;
    private TransaksiAdapter adapter;
    private final List<Transaksi> daftarTransaksi = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvTransaksi = findViewById(R.id.rvTransaksi);
        swipeRefresh = findViewById(R.id.swipeRefresh);
        tvEmpty = findViewById(R.id.tvEmpty);
        tvSaldo = findViewById(R.id.tvSaldo);
        progressBar = findViewById(R.id.progressBar);
        FloatingActionButton fabAdd = findViewById(R.id.fabAdd);

        rvTransaksi.setLayoutManager(new LinearLayoutManager(this));
        adapter = new TransaksiAdapter(daftarTransaksi, this::bukaEditTransaksi, this::konfirmasiHapus);
        rvTransaksi.setAdapter(adapter);

        swipeRefresh.setOnRefreshListener(this::muatDataTransaksi);

        // Intent: berpindah dari MainActivity ke AddEditActivity untuk menambah data baru
        fabAdd.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddEditActivity.class);
            intent.putExtra(EXTRA_MODE, MODE_ADD);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        muatDataTransaksi();
    }

    /**
     * Mengambil seluruh data transaksi dari REST API (GET read.php) yang terhubung ke MySQL.
     */
    private void muatDataTransaksi() {
        progressBar.setVisibility(View.VISIBLE);
        tvEmpty.setVisibility(View.GONE);

        ApiClient.getApiService().getAllTransaksi().enqueue(new Callback<List<Transaksi>>() {
            @Override
            public void onResponse(Call<List<Transaksi>> call, Response<List<Transaksi>> response) {
                progressBar.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);

                if (response.isSuccessful() && response.body() != null) {
                    daftarTransaksi.clear();
                    daftarTransaksi.addAll(response.body());
                    adapter.setData(daftarTransaksi);
                    tvEmpty.setVisibility(daftarTransaksi.isEmpty() ? View.VISIBLE : View.GONE);
                    hitungSaldo();
                } else {
                    Toast.makeText(MainActivity.this, "Gagal memuat data dari server", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Transaksi>> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);
                Toast.makeText(MainActivity.this,
                        "Koneksi ke server gagal. Pastikan backend & XAMPP aktif.\n" + t.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    private void hitungSaldo() {
        double saldo = 0;
        for (Transaksi t : daftarTransaksi) {
            saldo += "Pemasukan".equalsIgnoreCase(t.getTipe()) ? t.getJumlah() : -t.getJumlah();
        }
        NumberFormat formatRupiah = NumberFormat.getNumberInstance(new Locale("in", "ID"));
        tvSaldo.setText("Rp " + formatRupiah.format(saldo));
    }

    /**
     * Intent: berpindah ke AddEditActivity dalam mode edit, membawa data transaksi terpilih.
     */
    private void bukaEditTransaksi(Transaksi transaksi) {
        Intent intent = new Intent(MainActivity.this, AddEditActivity.class);
        intent.putExtra(EXTRA_MODE, MODE_EDIT);
        intent.putExtra(EXTRA_ID, transaksi.getId());
        intent.putExtra(EXTRA_JUDUL, transaksi.getJudul());
        intent.putExtra(EXTRA_KATEGORI, transaksi.getKategori());
        intent.putExtra(EXTRA_TIPE, transaksi.getTipe());
        intent.putExtra(EXTRA_JUMLAH, transaksi.getJumlah());
        intent.putExtra(EXTRA_TANGGAL, transaksi.getTanggal());
        intent.putExtra(EXTRA_DESKRIPSI, transaksi.getDeskripsi());
        startActivity(intent);
    }

    private void konfirmasiHapus(Transaksi transaksi) {
        new AlertDialog.Builder(this)
                .setTitle("Hapus Transaksi")
                .setMessage("Yakin ingin menghapus \"" + transaksi.getJudul() + "\"?")
                .setPositiveButton("Hapus", (dialog, which) -> hapusTransaksi(transaksi))
                .setNegativeButton("Batal", null)
                .show();
    }

    /**
     * Menghapus data melalui REST API (POST delete.php) -> menghapus baris di MySQL.
     */
    private void hapusTransaksi(Transaksi transaksi) {
        ApiClient.getApiService().deleteTransaksi(transaksi.getId()).enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                if (response.isSuccessful() && response.body() != null && response.body().isSuccess()) {
                    Toast.makeText(MainActivity.this, "Transaksi dihapus", Toast.LENGTH_SHORT).show();
                    muatDataTransaksi();
                } else {
                    Toast.makeText(MainActivity.this, "Gagal menghapus data", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Koneksi gagal: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
