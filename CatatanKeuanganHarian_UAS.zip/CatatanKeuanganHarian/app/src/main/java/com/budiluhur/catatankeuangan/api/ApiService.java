package com.budiluhur.catatankeuangan.api;

import com.budiluhur.catatankeuangan.model.ApiResponse;
import com.budiluhur.catatankeuangan.model.Transaksi;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

/**
 * Daftar endpoint REST API yang digunakan aplikasi.
 * Seluruh operasi CRUD (Create, Read, Update, Delete) dilakukan melalui endpoint ini,
 * yang terhubung ke backend PHP + database MySQL/MariaDB (lihat folder /backend).
 */
public interface ApiService {

    // READ - Mengambil seluruh data transaksi
    // GET {BASE_URL}read.php
    @GET("read.php")
    Call<List<Transaksi>> getAllTransaksi();

    // CREATE - Menambah transaksi baru
    // POST {BASE_URL}create.php
    @FormUrlEncoded
    @POST("create.php")
    Call<ApiResponse> createTransaksi(
            @Field("judul") String judul,
            @Field("kategori") String kategori,
            @Field("tipe") String tipe,
            @Field("jumlah") double jumlah,
            @Field("tanggal") String tanggal,
            @Field("deskripsi") String deskripsi
    );

    // UPDATE - Mengubah transaksi berdasarkan id
    // POST {BASE_URL}update.php
    @FormUrlEncoded
    @POST("update.php")
    Call<ApiResponse> updateTransaksi(
            @Field("id") int id,
            @Field("judul") String judul,
            @Field("kategori") String kategori,
            @Field("tipe") String tipe,
            @Field("jumlah") double jumlah,
            @Field("tanggal") String tanggal,
            @Field("deskripsi") String deskripsi
    );

    // DELETE - Menghapus transaksi berdasarkan id
    // POST {BASE_URL}delete.php
    @FormUrlEncoded
    @POST("delete.php")
    Call<ApiResponse> deleteTransaksi(
            @Field("id") int id
    );
}
