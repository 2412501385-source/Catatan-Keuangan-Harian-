package com.budiluhur.catatankeuangan.model;

import com.google.gson.annotations.SerializedName;

/**
 * Model data Transaksi Keuangan.
 * Field-field ini dipetakan langsung ke kolom tabel `transaksi` pada database MySQL/MariaDB
 * melalui REST API (lihat backend/read.php, create.php, update.php, delete.php).
 */
public class Transaksi {

    @SerializedName("id")
    private int id;

    @SerializedName("judul")
    private String judul;

    @SerializedName("kategori")
    private String kategori;

    @SerializedName("tipe")
    private String tipe; // "Pemasukan" atau "Pengeluaran"

    @SerializedName("jumlah")
    private double jumlah;

    @SerializedName("tanggal")
    private String tanggal; // format yyyy-MM-dd

    @SerializedName("deskripsi")
    private String deskripsi;

    public Transaksi() {
    }

    public Transaksi(String judul, String kategori, String tipe, double jumlah, String tanggal, String deskripsi) {
        this.judul = judul;
        this.kategori = kategori;
        this.tipe = tipe;
        this.jumlah = jumlah;
        this.tanggal = tanggal;
        this.deskripsi = deskripsi;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getKategori() {
        return kategori;
    }

    public void setKategori(String kategori) {
        this.kategori = kategori;
    }

    public String getTipe() {
        return tipe;
    }

    public void setTipe(String tipe) {
        this.tipe = tipe;
    }

    public double getJumlah() {
        return jumlah;
    }

    public void setJumlah(double jumlah) {
        this.jumlah = jumlah;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }
}
