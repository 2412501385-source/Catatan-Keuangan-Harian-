package com.budiluhur.catatankeuangan.api;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Singleton untuk membangun instance Retrofit yang menghubungkan aplikasi ke REST API backend.
 *
 * PENTING - SESUAIKAN BASE_URL:
 * - Jika backend dijalankan di XAMPP/Laragon lokal & diuji menggunakan Android EMULATOR,
 *   gunakan alamat host loopback emulator: "http://10.0.2.2/catatan_keuangan_api/"
 * - Jika diuji menggunakan HP FISIK pada jaringan WiFi yang sama dengan komputer server,
 *   gunakan IP lokal komputer, misalnya: "http://192.168.1.10/catatan_keuangan_api/"
 * - Jika sudah hosting (sesuai ketentuan soal nomor 2), gunakan domain hosting, misalnya:
 *   "https://namadomainanda.com/api/"
 */
public class ApiClient {

    private static final String BASE_URL = "http://10.0.2.2/catatan_keuangan_api/";

    private static Retrofit retrofit;

    public static Retrofit getRetrofitInstance() {
        if (retrofit == null) {
            HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
            logging.setLevel(HttpLoggingInterceptor.Level.BODY);

            OkHttpClient client = new OkHttpClient.Builder()
                    .addInterceptor(logging)
                    .build();

            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }

    public static ApiService getApiService() {
        return getRetrofitInstance().create(ApiService.class);
    }
}
