package com.budiluhur.catatankeuangan;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.budiluhur.catatankeuangan.api.ApiClient;
import com.budiluhur.catatankeuangan.model.ApiResponse;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.Calendar;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Activity 3 dari 3: Form Tambah / Ubah Transaksi.
 *
 * Mengimplementasikan VALIDASI INPUT sesuai ketentuan soal:
 * - Judul tidak boleh kosong
 * - Jumlah tidak boleh kosong, harus berupa angka, dan harus > 0
 * - Tanggal tidak boleh kosong
 * Data yang sudah valid baru dikirim ke REST API (create.php / update.php) untuk
 * disimpan ke database MySQL.
 */
public class AddEditActivity extends AppCompatActivity {

    private TextInputLayout tilJudul, tilJumlah, tilTanggal;
    private TextInputEditText etJudul, etJumlah, etTanggal, etDeskripsi;
    private RadioGroup rgTipe;
    private Spinner spinnerKategori;
    private Button btnSimpan;
    private View progressBar;

    private boolean isEditMode = false;
    private int transaksiId = -1;

    private static final String[] DAFTAR_KATEGORI = {
            "Makanan & Minuman", "Transportasi", "Belanja", "Pendidikan",
            "Kesehatan", "Hiburan", "Gaji/Pemasukan", "Lainnya"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        tilJudul = findViewById(R.id.tilJudul);
        tilJumlah = findViewById(R.id.tilJumlah);
        tilTanggal = findViewById(R.id.tilTanggal);
        etJudul = findViewById(R.id.etJudul);
        etJumlah = findViewById(R.id.etJumlah);
        etTanggal = findViewById(R.id.etTanggal);
        etDeskripsi = findViewById(R.id.etDeskripsi);
        rgTipe = findViewById(R.id.rgTipe);
        spinnerKategori = findViewById(R.id.spinnerKategori);
        btnSimpan = findViewById(R.id.btnSimpan);
        progressBar = findViewById(R.id.progressBar);

        ArrayAdapter<String> kategoriAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, DAFTAR_KATEGORI);
        spinnerKategori.setAdapter(kategoriAdapter);

        etTanggal.setOnClickListener(v -> tampilkanDatePicker());

        // Cek mode: tambah baru atau edit data lama (dikirim via Intent dari MainActivity)
        String mode = getIntent().getStringExtra(MainActivity.EXTRA_MODE);
        if (MainActivity.MODE_EDIT.equals(mode)) {
            isEditMode = true;
            getSupportActionBar().setTitle("Ubah Transaksi");
            isiDataDariIntent();
        } else {
            getSupportActionBar().setTitle("Tambah Transaksi");
        }

        btnSimpan.setOnClickListener(v -> validasiDanSimpan());
    }

    private void isiDataDariIntent() {
        transaksiId = getIntent().getIntExtra(MainActivity.EXTRA_ID, -1);
        etJudul.setText(getIntent().getStringExtra(MainActivity.EXTRA_JUDUL));
        etTanggal.setText(getIntent().getStringExtra(MainActivity.EXTRA_TANGGAL));
        etDeskripsi.setText(getIntent().getStringExtra(MainActivity.EXTRA_DESKRIPSI));
        etJumlah.setText(String.valueOf(getIntent().getDoubleExtra(MainActivity.EXTRA_JUMLAH, 0)));

        String kategori = getIntent().getStringExtra(MainActivity.EXTRA_KATEGORI);
        for (int i = 0; i < DAFTAR_KATEGORI.length; i++) {
            if (DAFTAR_KATEGORI[i].equalsIgnoreCase(kategori)) {
                spinnerKategori.setSelection(i);
                break;
            }
        }

        String tipe = getIntent().getStringExtra(MainActivity.EXTRA_TIPE);
        RadioButton rbPemasukan = findViewById(R.id.rbPemasukan);
        RadioButton rbPengeluaran = findViewById(R.id.rbPengeluaran);
        if ("Pemasukan".equalsIgnoreCase(tipe)) {
            rbPemasukan.setChecked(true);
        } else {
            rbPengeluaran.setChecked(true);
        }
    }

    private void tampilkanDatePicker() {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog dialog = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            String tanggal = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, dayOfMonth);
            etTanggal.setText(tanggal);
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        dialog.show();
    }

    /**
     * VALIDASI INPUT sebelum data dikirim ke server.
     * Mengembalikan true jika semua field valid.
     */
    private boolean validasiInput() {
        boolean valid = true;

        String judul = etJudul.getText() != null ? etJudul.getText().toString().trim() : "";
        if (TextUtils.isEmpty(judul)) {
            tilJudul.setError("Judul tidak boleh kosong");
            valid = false;
        } else {
            tilJudul.setError(null);
        }

        String jumlahStr = etJumlah.getText() != null ? etJumlah.getText().toString().trim() : "";
        if (TextUtils.isEmpty(jumlahStr)) {
            tilJumlah.setError("Jumlah tidak boleh kosong");
            valid = false;
        } else {
            try {
                double jumlah = Double.parseDouble(jumlahStr);
                if (jumlah <= 0) {
                    tilJumlah.setError("Jumlah harus lebih besar dari 0");
                    valid = false;
                } else {
                    tilJumlah.setError(null);
                }
            } catch (NumberFormatException e) {
                tilJumlah.setError("Jumlah harus berupa angka yang valid");
                valid = false;
            }
        }

        String tanggal = etTanggal.getText() != null ? etTanggal.getText().toString().trim() : "";
        if (TextUtils.isEmpty(tanggal)) {
            tilTanggal.setError("Tanggal wajib dipilih");
            valid = false;
        } else {
            tilTanggal.setError(null);
        }

        return valid;
    }

    private void validasiDanSimpan() {
        if (!validasiInput()) {
            Toast.makeText(this, "Periksa kembali input Anda", Toast.LENGTH_SHORT).show();
            return;
        }

        String judul = etJudul.getText().toString().trim();
        String kategori = (String) spinnerKategori.getSelectedItem();
        double jumlah = Double.parseDouble(etJumlah.getText().toString().trim());
        String tanggal = etTanggal.getText().toString().trim();
        String deskripsi = etDeskripsi.getText() != null ? etDeskripsi.getText().toString().trim() : "";

        int checkedId = rgTipe.getCheckedRadioButtonId();
        RadioButton rbChecked = findViewById(checkedId);
        String tipe = rbChecked.getText().toString();

        progressBar.setVisibility(View.VISIBLE);
        btnSimpan.setEnabled(false);

        if (isEditMode) {
            simpanUpdate(judul, kategori, tipe, jumlah, tanggal, deskripsi);
        } else {
            simpanBaru(judul, kategori, tipe, jumlah, tanggal, deskripsi);
        }
    }

    /** Mengirim data baru ke REST API (POST create.php) untuk disimpan ke MySQL. */
    private void simpanBaru(String judul, String kategori, String tipe, double jumlah, String tanggal, String deskripsi) {
        ApiClient.getApiService().createTransaksi(judul, kategori, tipe, jumlah, tanggal, deskripsi)
                .enqueue(new Callback<ApiResponse>() {
                    @Override
                    public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                        tanganiResponSimpan(response, "Transaksi berhasil ditambahkan");
                    }

                    @Override
                    public void onFailure(Call<ApiResponse> call, Throwable t) {
                        tanganiGagalSimpan(t);
                    }
                });
    }

    /** Mengirim perubahan data ke REST API (POST update.php) untuk mengubah data di MySQL. */
    private void simpanUpdate(String judul, String kategori, String tipe, double jumlah, String tanggal, String deskripsi) {
        ApiClient.getApiService().updateTransaksi(transaksiId, judul, kategori, tipe, jumlah, tanggal, deskripsi)
                .enqueue(new Callback<ApiResponse>() {
                    @Override
                    public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                        tanganiResponSimpan(response, "Transaksi berhasil diubah");
                    }

                    @Override
                    public void onFailure(Call<ApiResponse> call, Throwable t) {
                        tanganiGagalSimpan(t);
                    }
                });
    }

    private void tanganiResponSimpan(Response<ApiResponse> response, String pesanSukses) {
        progressBar.setVisibility(View.GONE);
        btnSimpan.setEnabled(true);

        if (response.isSuccessful() && response.body() != null && response.body().isSuccess()) {
            Toast.makeText(this, pesanSukses, Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Gagal menyimpan data ke server", Toast.LENGTH_SHORT).show();
        }
    }

    private void tanganiGagalSimpan(Throwable t) {
        progressBar.setVisibility(View.GONE);
        btnSimpan.setEnabled(true);
        Toast.makeText(this, "Koneksi gagal: " + t.getMessage(), Toast.LENGTH_LONG).show();
    }
}
