# Catatan Keuangan Harian

Aplikasi Android untuk tema **"Android Application for Everyday Problems"** — UAS Mobile Programming (PG119), Universitas Budi Luhur.

## a. Deskripsi Aplikasi

**Nama Aplikasi:** Catatan Keuangan Harian

**Latar Belakang:** Banyak orang, khususnya mahasiswa, kesulitan mengontrol pengeluaran dan pemasukan harian karena tidak memiliki catatan yang rapi dan mudah diakses. Pencatatan manual di buku sering hilang atau tidak konsisten.

**Tujuan Solusi:** Aplikasi ini memungkinkan pengguna mencatat transaksi pemasukan dan pengeluaran harian secara digital, melihat saldo terkini secara otomatis, serta mengelola (tambah/ubah/hapus) data tersebut. Seluruh data disimpan terpusat di server menggunakan database MySQL melalui REST API, sehingga data tidak hilang meskipun aplikasi di-uninstall (selama tersimpan di server).

## b. Daftar Fitur

1. **Splash Screen** — tampilan pembuka aplikasi.
2. **Lihat Daftar Transaksi** — menampilkan seluruh transaksi (pemasukan & pengeluaran) dalam bentuk list (RecyclerView), diambil real-time dari server.
3. **Ringkasan Saldo** — kartu saldo otomatis terhitung dari total pemasukan dikurangi pengeluaran.
4. **Tambah Transaksi** — form input transaksi baru dengan validasi.
5. **Ubah Transaksi** — mengedit transaksi yang sudah ada.
6. **Hapus Transaksi** — menghapus transaksi dengan dialog konfirmasi.
7. **Pull to Refresh** — menarik layar ke bawah untuk memuat ulang data dari server.
8. **Validasi Input** — mencegah data tidak valid (kosong/bukan angka/jumlah ≤ 0) terkirim ke server.

## c. Daftar Activity dan Fungsinya

| Activity | Fungsi |
|---|---|
| `SplashActivity` | Halaman pembuka, menampilkan logo/branding selama 2 detik sebelum berpindah ke `MainActivity`. |
| `MainActivity` | Halaman utama: menampilkan daftar transaksi (RecyclerView), saldo, serta navigasi tambah/ubah/hapus data. |
| `AddEditActivity` | Form tambah & ubah transaksi (mode ditentukan dari Intent), termasuk validasi input dan pengiriman data ke REST API. |

## d. Daftar Intent dan Tujuannya

| Intent (dari → ke) | Tujuan |
|---|---|
| `SplashActivity` → `MainActivity` | Berpindah otomatis setelah splash screen selesai. |
| `MainActivity` → `AddEditActivity` (mode `add`) | Membuka form kosong untuk menambah transaksi baru (lewat tombol FAB +). |
| `MainActivity` → `AddEditActivity` (mode `edit`) | Membuka form yang sudah terisi data transaksi terpilih (lewat klik item RecyclerView), membawa extra data: id, judul, kategori, tipe, jumlah, tanggal, deskripsi. |

## e. Daftar Widget Android yang Digunakan

- `RecyclerView` — menampilkan daftar transaksi secara dinamis.
- `SwipeRefreshLayout` — pull-to-refresh data.
- `CardView` — kartu saldo & item transaksi.
- `TextInputLayout` + `TextInputEditText` (Material) — input form dengan label & error validasi.
- `Spinner` — pilihan kategori transaksi.
- `RadioGroup` + `RadioButton` — pilihan tipe (Pemasukan/Pengeluaran).
- `FloatingActionButton` — tombol tambah transaksi.
- `Button`, `ImageButton`, `TextView`, `ProgressBar`, `Toolbar`, `AlertDialog`, `DatePickerDialog`.

## f. Library Tambahan dan Alasan Penggunaan

| Library | Alasan |
|---|---|
| **Retrofit2 + Converter-Gson** | Mempermudah pemanggilan REST API ke backend PHP dan otomatis mengubah JSON response menjadi objek Java (`Transaksi`, `ApiResponse`). |
| **OkHttp Logging Interceptor** | Membantu debugging request/response API selama pengembangan. |
| **Material Components** | Menyediakan komponen UI modern (TextInputLayout, FloatingActionButton) yang sudah mendukung validasi visual (error text) bawaan. |

## g. Database — Entity Relationship Diagram (ERD)

Aplikasi ini menggunakan **satu entitas utama**: `transaksi`.

```
┌──────────────────────────────┐
│           transaksi          │
├──────────────────────────────┤
│ PK  id            INT        │
│     judul         VARCHAR    │
│     kategori      VARCHAR    │
│     tipe          ENUM       │  ('Pemasukan' | 'Pengeluaran')
│     jumlah        DECIMAL    │
│     tanggal       DATE       │
│     deskripsi     TEXT       │
│     created_at    TIMESTAMP  │
│     updated_at    TIMESTAMP  │
└──────────────────────────────┘
```

Skema lengkap tersedia di `backend/database.sql`.

---

## Daftar REST API Endpoint

Base URL contoh (lokal via XAMPP + emulator): `http://10.0.2.2/catatan_keuangan_api/`

### 1. GET `read.php` — Mengambil semua transaksi

**Request:** `GET /read.php`

**Response (200):**
```json
[
  {
    "id": 1,
    "judul": "Gaji Bulanan",
    "kategori": "Gaji/Pemasukan",
    "tipe": "Pemasukan",
    "jumlah": 2500000,
    "tanggal": "2026-06-25",
    "deskripsi": "Gaji part time bulan Juni"
  }
]
```

### 2. POST `create.php` — Menambah transaksi baru

**Request (form-urlencoded):**
```
judul=Beli Buku Tulis
kategori=Belanja
tipe=Pengeluaran
jumlah=15000
tanggal=2026-06-26
deskripsi=Buku untuk catatan kuliah
```

**Response sukses (200):**
```json
{"status": "success", "message": "Transaksi berhasil ditambahkan", "id": 5}
```

**Response gagal (400):**
```json
{"status": "error", "message": "Data tidak valid. Judul, tanggal, dan jumlah (>0) wajib diisi."}
```

### 3. POST `update.php` — Mengubah transaksi

**Request (form-urlencoded):**
```
id=5
judul=Beli Buku Tulis & Pensil
kategori=Belanja
tipe=Pengeluaran
jumlah=18000
tanggal=2026-06-26
deskripsi=Tambah pensil
```

**Response sukses (200):**
```json
{"status": "success", "message": "Transaksi berhasil diubah"}
```

### 4. POST `delete.php` — Menghapus transaksi

**Request (form-urlencoded):**
```
id=5
```

**Response sukses (200):**
```json
{"status": "success", "message": "Transaksi berhasil dihapus"}
```

**Response gagal (404):**
```json
{"status": "error", "message": "Data dengan id tersebut tidak ditemukan"}
```

---

## Panduan Instalasi & Menjalankan Aplikasi

### 1. Setup Backend (PHP + MySQL)
1. Install **XAMPP/Laragon**, aktifkan Apache & MySQL.
2. Copy folder `backend/` ke `htdocs/catatan_keuangan_api/` (XAMPP) atau folder `www` (Laragon).
3. Buka phpMyAdmin, import `backend/database.sql` untuk membuat database `catatan_keuangan` beserta data contoh.
4. Uji endpoint di browser: `http://localhost/catatan_keuangan_api/read.php` — harus tampil data JSON.

### 2. Setup Android Studio
1. Buka folder project `CatatanKeuanganHarian/` di Android Studio.
2. Tunggu proses Gradle Sync selesai (pastikan koneksi internet untuk download dependency Retrofit dkk).
3. Cek `app/src/main/java/.../api/ApiClient.java`, sesuaikan `BASE_URL`:
   - Emulator → `http://10.0.2.2/catatan_keuangan_api/`
   - HP fisik (1 jaringan WiFi) → `http://<IP_LOKAL_KOMPUTER>/catatan_keuangan_api/`
   - Setelah hosting → `https://domainanda.com/api/`
4. Jalankan aplikasi (Run ▶) pada emulator atau perangkat fisik.

### 3. Hosting (untuk pemenuhan soal nomor 2)
1. Upload folder `backend/` ke hosting (cPanel File Manager atau FTP).
2. Import `database.sql` ke database MySQL hosting via phpMyAdmin.
3. Update kredensial di `backend/db.php` sesuai detail database hosting.
4. Update `BASE_URL` di `ApiClient.java` ke domain hosting, lalu build ulang APK.

---

## Struktur Folder Project

```
CatatanKeuanganHarian/
├── app/
│   └── src/main/
│       ├── java/com/budiluhur/catatankeuangan/
│       │   ├── SplashActivity.java
│       │   ├── MainActivity.java
│       │   ├── AddEditActivity.java
│       │   ├── model/
│       │   │   ├── Transaksi.java
│       │   │   └── ApiResponse.java
│       │   ├── adapter/
│       │   │   └── TransaksiAdapter.java
│       │   └── api/
│       │       ├── ApiClient.java
│       │       └── ApiService.java
│       ├── res/
│       │   ├── layout/ (activity_splash, activity_main, activity_add_edit, item_transaksi)
│       │   └── values/ (strings, colors, themes)
│       └── AndroidManifest.xml
├── backend/
│   ├── db.php
│   ├── read.php
│   ├── create.php
│   ├── update.php
│   ├── delete.php
│   └── database.sql
└── README.md
```

## Catatan Penting

- Aplikasi **tidak menggunakan database lokal** (SQLite/Room) sebagai basis data utama — sesuai ketentuan soal, seluruh data utama tersimpan di MySQL dan diakses melalui REST API.
- Fitur Firebase (Authentication/Cloud Storage/Push Notification) **belum diimplementasikan** pada versi ini — dapat ditambahkan sebagai nilai plus opsional sesuai ketentuan soal bila diperlukan.
- Jangan lupa mengisi **URL Repository GitHub kedua anggota** (jika dikerjakan berkelompok) saat pengumpulan ke e-learning.
