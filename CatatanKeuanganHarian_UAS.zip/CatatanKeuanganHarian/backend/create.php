<?php
/**
 * create.php
 * Endpoint: POST /create.php
 * Body (form-urlencoded): judul, kategori, tipe, jumlah, tanggal, deskripsi
 * Menyimpan satu baris data transaksi baru ke database MySQL.
 * Response: {"status":"success","message":"..."} atau {"status":"error","message":"..."}
 */

require_once "db.php";

$judul     = isset($_POST["judul"]) ? trim($_POST["judul"]) : "";
$kategori  = isset($_POST["kategori"]) ? trim($_POST["kategori"]) : "";
$tipe      = isset($_POST["tipe"]) ? trim($_POST["tipe"]) : "Pengeluaran";
$jumlah    = isset($_POST["jumlah"]) ? (float) $_POST["jumlah"] : 0;
$tanggal   = isset($_POST["tanggal"]) ? trim($_POST["tanggal"]) : "";
$deskripsi = isset($_POST["deskripsi"]) ? trim($_POST["deskripsi"]) : "";

// Validasi server-side (lapisan kedua, selain validasi di sisi Android)
if (empty($judul) || empty($tanggal) || $jumlah <= 0) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => "Data tidak valid. Judul, tanggal, dan jumlah (>0) wajib diisi."
    ]);
    exit();
}

$stmt = $koneksi->prepare(
    "INSERT INTO transaksi (judul, kategori, tipe, jumlah, tanggal, deskripsi) VALUES (?, ?, ?, ?, ?, ?)"
);
$stmt->bind_param("sssdss", $judul, $kategori, $tipe, $jumlah, $tanggal, $deskripsi);

if ($stmt->execute()) {
    echo json_encode([
        "status" => "success",
        "message" => "Transaksi berhasil ditambahkan",
        "id" => $stmt->insert_id
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Gagal menyimpan data: " . $stmt->error
    ]);
}

$stmt->close();
$koneksi->close();
