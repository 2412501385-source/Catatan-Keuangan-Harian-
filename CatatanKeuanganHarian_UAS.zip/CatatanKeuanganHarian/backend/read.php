<?php
/**
 * read.php
 * Endpoint: GET /read.php
 * Mengambil seluruh data transaksi dari database, diurutkan dari tanggal terbaru.
 * Response: JSON array of objects, contoh:
 * [
 *   {"id":1,"judul":"Gaji Bulanan","kategori":"Gaji/Pemasukan","tipe":"Pemasukan",
 *    "jumlah":2500000,"tanggal":"2026-06-25","deskripsi":"Gaji part time bulan Juni"}
 * ]
 */

require_once "db.php";

$query = "SELECT id, judul, kategori, tipe, jumlah, tanggal, deskripsi FROM transaksi ORDER BY tanggal DESC, id DESC";
$result = $koneksi->query($query);

$data = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = [
            "id"        => (int) $row["id"],
            "judul"     => $row["judul"],
            "kategori"  => $row["kategori"],
            "tipe"      => $row["tipe"],
            "jumlah"    => (float) $row["jumlah"],
            "tanggal"   => $row["tanggal"],
            "deskripsi" => $row["deskripsi"]
        ];
    }
}

echo json_encode($data);

$koneksi->close();
