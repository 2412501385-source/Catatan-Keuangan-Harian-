<?php
/**
 * db.php
 * Konfigurasi koneksi ke database MySQL/MariaDB.
 * SESUAIKAN nilai berikut dengan konfigurasi server/hosting Anda.
 */

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "catatan_keuangan";

$koneksi = new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($koneksi->connect_error) {
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Koneksi database gagal: " . $koneksi->connect_error
    ]);
    exit();
}

$koneksi->set_charset("utf8mb4");
