<?php
/**
 * update.php
 * Endpoint: POST /update.php
 * Body (form-urlencoded): id, judul, kategori, tipe, jumlah, tanggal, deskripsi
 * Mengubah data transaksi yang sudah ada berdasarkan id.
 * Response: {"status":"success","message":"..."} atau {"status":"error","message":"..."}
 */

require_once "db.php";

$id        = isset($_POST["id"]) ? (int) $_POST["id"] : 0;
$judul     = isset($_POST["judul"]) ? trim($_POST["judul"]) : "";
$kategori  = isset($_POST["kategori"]) ? trim($_POST["kategori"]) : "";
$tipe      = isset($_POST["tipe"]) ? trim($_POST["tipe"]) : "Pengeluaran";
$jumlah    = isset($_POST["jumlah"]) ? (float) $_POST["jumlah"] : 0;
$tanggal   = isset($_POST["tanggal"]) ? trim($_POST["tanggal"]) : "";
$deskripsi = isset($_POST["deskripsi"]) ? trim($_POST["deskripsi"]) : "";

if ($id <= 0 || empty($judul) || empty($tanggal) || $jumlah <= 0) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => "Data tidak valid atau id tidak ditemukan."
    ]);
    exit();
}

$stmt = $koneksi->prepare(
    "UPDATE transaksi SET judul=?, kategori=?, tipe=?, jumlah=?, tanggal=?, deskripsi=? WHERE id=?"
);
$stmt->bind_param("sssdssi", $judul, $kategori, $tipe, $jumlah, $tanggal, $deskripsi, $id);

if ($stmt->execute()) {
    echo json_encode([
        "status" => "success",
        "message" => "Transaksi berhasil diubah"
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Gagal mengubah data: " . $stmt->error
    ]);
}

$stmt->close();
$koneksi->close();
