<?php
/**
 * delete.php
 * Endpoint: POST /delete.php
 * Body (form-urlencoded): id
 * Menghapus satu baris data transaksi berdasarkan id.
 * Response: {"status":"success","message":"..."} atau {"status":"error","message":"..."}
 */

require_once "db.php";

$id = isset($_POST["id"]) ? (int) $_POST["id"] : 0;

if ($id <= 0) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => "ID tidak valid."
    ]);
    exit();
}

$stmt = $koneksi->prepare("DELETE FROM transaksi WHERE id=?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo json_encode([
            "status" => "success",
            "message" => "Transaksi berhasil dihapus"
        ]);
    } else {
        http_response_code(404);
        echo json_encode([
            "status" => "error",
            "message" => "Data dengan id tersebut tidak ditemukan"
        ]);
    }
} else {
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Gagal menghapus data: " . $stmt->error
    ]);
}

$stmt->close();
$koneksi->close();
