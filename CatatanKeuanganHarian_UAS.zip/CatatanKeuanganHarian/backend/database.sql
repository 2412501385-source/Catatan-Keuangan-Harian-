-- =====================================================
-- Database: catatan_keuangan
-- Tabel utama untuk aplikasi Catatan Keuangan Harian
-- =====================================================

CREATE DATABASE IF NOT EXISTS catatan_keuangan;
USE catatan_keuangan;

CREATE TABLE IF NOT EXISTS transaksi (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    judul VARCHAR(150) NOT NULL,
    kategori VARCHAR(50) NOT NULL,
    tipe ENUM('Pemasukan', 'Pengeluaran') NOT NULL DEFAULT 'Pengeluaran',
    jumlah DECIMAL(15,2) NOT NULL,
    tanggal DATE NOT NULL,
    deskripsi TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Contoh data dummy untuk pengujian
INSERT INTO transaksi (judul, kategori, tipe, jumlah, tanggal, deskripsi) VALUES
('Gaji Bulanan', 'Gaji/Pemasukan', 'Pemasukan', 2500000, '2026-06-25', 'Gaji part time bulan Juni'),
('Beli Buku Tulis', 'Belanja', 'Pengeluaran', 15000, '2026-06-26', 'Buku untuk catatan kuliah'),
('Makan Siang', 'Makanan & Minuman', 'Pengeluaran', 25000, '2026-06-27', 'Makan siang di kantin kampus'),
('Bensin Motor', 'Transportasi', 'Pengeluaran', 20000, '2026-06-28', 'Isi bensin untuk ke kampus');
